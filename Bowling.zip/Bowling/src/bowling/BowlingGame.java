package bowling;


public class BowlingGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game g=new Game();
		g.startGame();
		//Bowling game=new Bowling(playerCount);
		//game.start();
		
	}

}
